#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"

treenode* return_node(treenode *root, char *token)
{
    if (root == NULL)
        return;
    if (strcmp(root->token->arr, token) == 0 && flag == 0)
    {
        flag = 1;
        return root;
        printf("inside return_node func. Content of node_found\n");
        // return;
    }
    for (int i = 0; i < 10; i++)
    {
        if(root->children[i]==NULL)
        {
            break;
        }
        else{
            return return_node(root->children[i], token);
        }
        
    }
}



for( auto a : grammar)
{
    for(auto rule : a)
    {
        if(terminal == rule)
        {
            return rule_no
        }
    }
}