#include "parsetable.h"
#include <stdio.h>     //i can see uuuuuuuuu
#include "ternonter.h" // can you see me??

void init_parsetable()
{
    printf("allocating space for parsetable...\n");
    parsetable = (parseUnit **)malloc(NON_TERMINAL_COUNT * sizeof(parseUnit *));
    for (int i = 0; i < NON_TERMINAL_COUNT; i++)
    {
        parsetable[i] = (parseUnit *)malloc(TERMINAL_COUNT * sizeof(parseUnit));
    }
    for (int i = 0; i < NON_TERMINAL_COUNT; i++)
    {
        for (int j = 0; j < TERMINAL_COUNT; j++)
        {
            parsetable[i][j].rule_number = -1;
            parsetable[i][j].or_no = -1;
        }
    }
    // printf("\nfrom init parsetable : %d0 %d\n",parsetable[0][13].rule_number,parsetable[0][13].or_no );
}

int getTerminalNumber(char *lexeme)
{

    for (int i = 0; i < TERMINAL_COUNT; i++)
    {
        if (strcmp(lexeme, terminals[i]) == 0)
            return i;
    }
    printf("Didnt find the terminal:%s\n", lexeme);
    return -1;
}

int getNonTerminalNumber(char *lexeme)
{
    for (int i = 0; i < NON_TERMINAL_COUNT; i++)
    {

        if (strcmp(lexeme, nonterminals[i]) == 0)
        {
            return i;
        }
    }
    printf("Didnt find the non-terminal:%s\n", lexeme);
    return -1;
}

parseUnit *returnElement(int row, int col)
{
    return &parsetable[row][col];
}

void generate_parsetable(firstAndfollow *ruleset, lhs *Grammar)
{
    for (int i = 0; i < sizeOfGrammer; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (grammar[i].rule[j] != NULL)
            {
                if (grammar[i].rule[j]->token[0] != 'T' && grammar[i].rule[j]->token[0] != '$')
                {
                    int x = getNonTerminalNumber(grammar[i].rule[j]->token);
                    // printf("x : %d\n", x);
                    firstAndfollow first_set_ptr_;
                    // printf("token : %s\n", grammar[i].rule[j]->token);
                    // int count =0;
                    for (int k = 0; k < 60; k++)
                    {
                        
                        if (strcmp(grammar[i].rule[j]->token, ruleset[k].token) == 0)
                        {
                            first_set_ptr_ = ruleset[k];
                            // count++;
                            // printf("nt for the fnfset :%d %s\n",k, ruleset[k].token);
                            break;
                        }
                    }
                    first *first_set_ptr = first_set_ptr_.First;
                    // printf("first_set : %s, token : %s\n", first_set_ptr_.token, grammar[i].rule[j]->token);
                    // printf(" count : %d\n", count);
                    while (first_set_ptr != NULL)
                    {
                        int term_no = getTerminalNumber(first_set_ptr->token);
                        int non_term_no = getNonTerminalNumber(grammar[i].nonterminal);
                        parsetable[non_term_no][term_no].rule_number = i;
                        parsetable[non_term_no][term_no].or_no = j;
                        // printf("term_no : %d, non_term_no : %d, ( %d, %d )\n", term_no, non_term_no, parsetable[non_term_no][term_no].rule_number, parsetable[non_term_no][term_no].or_no);
                        first_set_ptr = first_set_ptr->next;
                        // printf("%s\n",first_set_ptr->token);
                    }
                    // first_set_ptr = ruleset[j].First;
                    follow *follow_set_ptr = first_set_ptr_.Follow;
                    if (first_set_ptr_.epsPres == 1)
                    {
                        // printf("Inside if condition of follow\n");
                        while (follow_set_ptr != NULL)
                        {
                            // if(strcmp(follow_set_ptr->token,"$")) // hopefully it is not needed
                            // {

                            // }
                            int term_no = getTerminalNumber(follow_set_ptr->token);
                            int non_term_no = getNonTerminalNumber(grammar[i].nonterminal);
                            parsetable[non_term_no][term_no].rule_number = i;
                            parsetable[non_term_no][term_no].or_no = j;
                            // printf("term_no : %d, non_term_no : %d, ( %d, %d )\n", term_no, non_term_no, parsetable[non_term_no][term_no].rule_number, parsetable[non_term_no][term_no].or_no);
                            follow_set_ptr = follow_set_ptr->next;
                        }
                    }
                }
                else
                { // added this

                    int term_no = getTerminalNumber(grammar[i].rule[j]->token);
                    int non_term_no = getNonTerminalNumber(grammar[i].nonterminal);
                    parsetable[non_term_no][term_no].rule_number = i;
                    parsetable[non_term_no][term_no].or_no = j;
                    // printf("term_no : %d, non_term_no : %d, ( %d, %d )\n", term_no, non_term_no, parsetable[non_term_no][term_no].rule_number, parsetable[non_term_no][term_no].or_no);
                }
            }
        }
    }
    printf("Value of (0,13) : %d %d\n", parsetable[0][13].rule_number, parsetable[0][13].or_no);
}

void print_table()
{
    for (int i = 0; i < NON_TERMINAL_COUNT; i++)
    {
        for (int j = 0; j < TERMINAL_COUNT; j++)
        { // if(parsetable[i][j].rule_number != -1 && parsetable[i][j].or_no != -1)
            printf("(%d,%d) ", parsetable[i][j].rule_number, parsetable[i][j].or_no);
        }
        printf("\n");
    }
}

void complete_init(firstAndfollow *ruleset, lhs *Grammar)
{
    init_parsetable();
    printf("Parse Table Initialized\n");
    generate_parsetable(ruleset, Grammar);
    // print_table();
}
