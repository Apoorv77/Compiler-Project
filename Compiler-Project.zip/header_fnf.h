
firstAndfollow * populateFirstandFollow(FILE* ptr);